const CONFIG = {
  server_url: "http://api.weatherapi.com",
  api_key: "bb3ca28e253e460b8e9194010243009",
  num_items_query: 8,
  num_items_show: 6,
  default_lat: 40.416775,
  default_lon: -3.703790,
  use_server: true,
  force_error: false  
}

export default CONFIG;